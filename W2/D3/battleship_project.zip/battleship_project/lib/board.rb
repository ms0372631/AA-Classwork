class Board
  
end
