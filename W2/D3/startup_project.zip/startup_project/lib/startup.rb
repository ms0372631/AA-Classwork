require "employee"

class Startup

end
